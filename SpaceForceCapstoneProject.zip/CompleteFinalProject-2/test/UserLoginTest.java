package test;
import org.junit.jupiter.api.*;

import src.UserLogin;

import static org.junit.jupiter.api.Assertions.*;

public class UserLoginTest {
    private UserLogin userLogin;

    @BeforeAll
    public static void setupAll() {
        System.out.println("Starting User Login Testing");
    }

    @BeforeEach
    public void setUp() {
        userLogin = new UserLogin();
    }

    @AfterEach
    public void tearDown() {
        userLogin = null;
    }

    @AfterAll
    public static void tearDownAll() {
        System.out.println("All Tests Completed");
    }

    @Test
    public void testInvalidPasswordMissingLowerCase() {
        String password = "1!Q";
        assertFalse(userLogin.validPassword(password), "Password '1!Q' should be invalid");
    }

    @Test
    public void testInvalidPasswordMissingUpperCase() {
        String password = "1!q";
        assertFalse(userLogin.validPassword(password), "Password '1!q' should be invalid");
    }

    @Test
    public void testInvalidPasswordMissingSpecialCharacter() {
        String password = "1Qq";
        assertFalse(userLogin.validPassword(password), "Password '1Qq' should be invalid");
    }

    @Test
    public void testInvalidPasswordMissingDigit() {
        String password = "!Qq";
        assertFalse(userLogin.validPassword(password), "Password '!Qq' should be invalid");
    }

    @Test
    public void testValidPassword() {
        String password = "1!Qq"; 
        assertTrue(userLogin.validPassword(password), "Password '1!Qq' should be valid");
    }


    //Testing userExists

    @Test
    public void testUserDoesExist(){
        String username = "Owner";
        assertTrue(userLogin.userExists(username), "User Exists In The Data Base");
    }

    @Test
    public void testUserDoesNotExist(){
        String username = "Jeff";
        assertFalse(userLogin.userExists(username), "User Exists In The Data Base");}
    


}
