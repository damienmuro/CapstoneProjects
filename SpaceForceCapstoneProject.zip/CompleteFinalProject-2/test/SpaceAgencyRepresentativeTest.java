package test;
import org.junit.jupiter.api.*;

import src.Debris;
import src.ObjectTypeNotFoundException;
import src.SpaceAgencyRepresentative;
import src.SpaceObject;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;

public class SpaceAgencyRepresentativeTest {

    private SpaceAgencyRepresentative spaceAgencyRepresentative;
    private List<SpaceObject> testObjects;
    private final int MAX_DAYS_OLD = 200;
    private final long MAX_CONJUNCTION_COUNT = 0;

    @BeforeAll
    public static void setupAll(){
        System.out.println("Space Agency Representative Testing...");
    }

    @BeforeEach
    public void setUp(){
        spaceAgencyRepresentative = new SpaceAgencyRepresentative();
        
        testObjects = new ArrayList<>();

        testObjects.add(new Debris("10096", "10096", "SL-14 R/B", "CIS", "LEO", "ROCKET BODY", 1977, "PKMTR", -70.94856912, -45.06140362, "62.925556,40.577778", null, false, null, false, null, null, null, 17390, 0, false, null, 0, null, 0, false));
        testObjects.add(new Debris("10436", "10436", "COSMOS 839 DEB", "CIS", "LEO", "DEBRIS", 1976, "PKMTR", 29.39840935, -32.93402367, "62.925556,40.577778", null, false, null, false, null, null, null, 17741, 0, false, null, 0, null, 0, false));
        testObjects.add(new Debris("28158", "28158", "USA 176", "US", "GEO", "PAYLOAD", 2004, "AFETR", 87.91604609, 87.1905644, "28.4917337,-80.5825555", "Blue", false, null, false, null, null, null, 7659, 1, false, null, 0, null, 0, false));
        testObjects.add(new Debris("47437", "47437", "OBJECT AA", "TBD", "LEO", "UNKNOWN", 2021, "AFETR", 30.6140765, -104.5134819, "28.4917337,-80.5825555", null, false, null, false, null, null, null, 1470, 0, false, null, 0, null, 0, false));
        testObjects.add(new Debris("57868", "57868", "STARLINK-30442", "US", "LEO", "PAYLOAD", 2023, "AFETR", 5.836206465, -24.70640827, "28.4917337,-80.5825555", null, false, null, false, null, null, null, 461, 2, false, null, 0, null, 0, false));

    }

    @AfterEach
    public void tearDown(){
        testObjects.clear();
    }

    @AfterAll
    public static void tearDownAll(){
        System.out.println("All Tests Completed...");
    }


    @Test
    public void testGetSpaceObjectsLEO(){
        List<SpaceObject> leoObjects = spaceAgencyRepresentative.getSpaceObjectsLEO(testObjects);
        assertEquals(4, leoObjects.size());
    }

    @Test
    public void testGetSpaceObjectsLEOInvalidCase(){
        List<SpaceObject> leoObjects = spaceAgencyRepresentative.getSpaceObjectsLEO(testObjects);
        assertFalse(leoObjects.isEmpty());
    }

    @Test
    public void testAnalyzeLongTermImpacts(){
        List<SpaceObject> longTermImpactObjects = spaceAgencyRepresentative.analyzeLongTermImpact(testObjects);
        assertEquals(1, longTermImpactObjects.size());
        assertTrue(longTermImpactObjects.get(0).getConjunction_count() > MAX_CONJUNCTION_COUNT);
        assertTrue(longTermImpactObjects.get(0).getDays_old() > MAX_DAYS_OLD);
    }

    @Test
    public void testAnalyzeLongTermImpactsInvalid(){
        List<SpaceObject> longTermImpactObjects = spaceAgencyRepresentative.analyzeLongTermImpact(testObjects);
        assertNotEquals(0, longTermImpactObjects.size());
        assertFalse(longTermImpactObjects.get(0).getConjunction_count() < MAX_CONJUNCTION_COUNT);
        assertFalse(longTermImpactObjects.get(0).getDays_old() < MAX_DAYS_OLD);
    }


}
