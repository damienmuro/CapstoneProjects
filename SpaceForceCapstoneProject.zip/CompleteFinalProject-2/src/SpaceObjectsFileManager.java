package src;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

/**
 * Manages file operations for space object data.
 * Handles loading, saving, and logging space object information.
 * @author Damien Muro
 * @author Ethan Patin
 * @author Christian Parra
 * @version Version 3.0
 */
public class SpaceObjectsFileManager {

    String newDataFile = "DebrisTrackingReport.csv";
    String systemLog = "SystemLog.csv";
    String dataFileInOutOrbit = "Exited_Vs_In_Orbit_Debris.txt";
    final String spaceObjectData = "rso_metrics_columns_jumbled.csv";

    /**
     * Loads space objects from a Jumbled CSV file.
     *
     * @param file Path to the CSV file.
     * @return List of SpaceObjects loaded from the file.
     */
    public List<SpaceObject> loadSpaceObjects(String file) {
        List<SpaceObject> spaceObjects = new ArrayList<>();
    
        try {
            File spaceObjectInfo = new File(file);
            Scanner fileReader = new Scanner(spaceObjectInfo);
    
            Map<String, Integer> columnMap = new HashMap<>();
            if (fileReader.hasNextLine()) {
                String headerLine = fileReader.nextLine();
                String[] headers = splitCSVLine(headerLine);
                for (int i = 0; i < headers.length; i++) {
                    columnMap.put(headers[i].trim().toLowerCase(), i);
                }
            }
    
            while (fileReader.hasNextLine()) {
                String data = fileReader.nextLine();
                String[] fields = splitCSVLine(data);
    
                try {
                    String record_id = getField(fields, columnMap, "record_id");
                    String norad_cat_id = getField(fields, columnMap, "norad_cat_id");
                    String satellite_name = getField(fields, columnMap, "satellite_name");
                    String country = getField(fields, columnMap, "country");
                    String approximate_orbit_type = getField(fields, columnMap, "approximate_orbit_type");
                    String object_type = getField(fields, columnMap, "object_type");
                    int launch_year = parseIntSafe(getField(fields, columnMap, "launch_year"), -1);
                    String launch_site = getField(fields, columnMap, "launch_site");
                    double longitude = parseDoubleSafe(getField(fields, columnMap, "longitude"), 0.0);
                    double avg_longitude = parseDoubleSafe(getField(fields, columnMap, "avg_longitude"), 0.0);
                    String geohash = getField(fields, columnMap, "geohash");
                    String HRR_Category = getField(fields, columnMap, "hrr_category");
                    boolean is_nominated = parseBooleanSafe(getField(fields, columnMap, "is_nominated"));
                    String nominated_at = getField(fields, columnMap, "nominated_at");
                    boolean has_dossier = parseBooleanSafe(getField(fields, columnMap, "has_dossier"));
                    String last_updated_at = getField(fields, columnMap, "last_updated_at");
                    String justification = getField(fields, columnMap, "justification");
                    String focused_raw = getField(fields, columnMap, "focused_analysis");
                    String[] focused_analysis = focused_raw.isEmpty() ? new String[0] : focused_raw.split(";");
                    int days_old = parseIntSafe(getField(fields, columnMap, "days_old"), -1);
                    long conjunction_count = parseLongSafe(getField(fields, columnMap, "conjunction_count"), 0L);
                    boolean is_unk_object = parseBooleanSafe(getField(fields, columnMap, "is_unk_object"));
                    String all_maneuvers = getField(fields, columnMap, "all_maneuvers");
                    int days_since_ob = parseIntSafe(getField(fields, columnMap, "days_since_ob"), -1);
                    String recent_maneuvers = getField(fields, columnMap, "recent_maneuvers");
                    double deltaV_90day = parseDoubleSafe(getField(fields, columnMap, "deltav_90day"), 0.0);
                    boolean has_sister_debris = parseBooleanSafe(getField(fields, columnMap, "has_sister_debris"));
    
                    Debris debris = new Debris(
                            record_id, norad_cat_id, satellite_name, country, approximate_orbit_type, object_type,
                            launch_year, launch_site, longitude, avg_longitude, geohash, HRR_Category, is_nominated,
                            nominated_at, has_dossier, last_updated_at, justification, focused_analysis, days_old,
                            conjunction_count, is_unk_object, all_maneuvers, days_since_ob, recent_maneuvers, deltaV_90day,
                            has_sister_debris
                    );
    
                    spaceObjects.add(debris);
    
                } catch (Exception e) {
                    System.err.println("Failed to parse row: " + data);
                    e.printStackTrace();
                }
            }
    
        } catch (FileNotFoundException e) {
            System.out.println("File not found");
        }
    
        return spaceObjects;
    }
    
    /**
     * Splits CSV line properly.
     *
     * @param line CSV line.
     * @return Separated values.
     */
    private String[] splitCSVLine(String line) {
        String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
    
        for (int i = 0; i < parts.length; i++) {
            parts[i] = parts[i].trim().replaceAll("^\"|\"$", "");
        }
    
        return parts;
    }
    


    /**
     * Gets field value from CSV data.
     *
     * @param fields The array of field values.
     * @param columnMap The map of column names to their indices.
     * @param key The column name to retrieve.
     * @return The field value as a string, or an empty string if the column is not found.
     */
    private String getField(String[] fields, Map<String, Integer> columnMap, String key) {
        Integer idx = columnMap.get(key.toLowerCase());
        if (idx == null || idx >= fields.length) return "";
        return fields[idx];
    }
    
    

     /**
     * Safely parses a string into an integer, returning a default value if parsing fails.
     *
     * @param str The string to parse.
     * @param defaultValue The default value to return if parsing fails.
     * @return The parsed integer or the default value.
     */
    private int parseIntSafe(String str, int defaultValue) {
        try {
            if (str == null || str.isEmpty()) {
                return defaultValue;
            } else {
                return Integer.parseInt(str);
            }
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    /**
     * Safely parses a string into a long, returning a default value if parsing fails.
     *
     * @param str The string to parse.
     * @param defaultValue The default value to return if parsing fails.
     * @return The parsed long or the default value.
     */
    private long parseLongSafe(String str, long defaultValue) {
        try {
            if (str == null || str.isEmpty()) {
                return defaultValue;
            } else {
                return Long.parseLong(str);
            }
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    /**
     * Safely parses a string into a long, returning a default value if parsing fails.
     *
     * @param str The string to parse.
     * @param defaultValue The default value to return if parsing fails.
     * @return The parsed double or the default value.
     */
    private double parseDoubleSafe(String str, double defaultValue) {
        try {
            if (str == null || str.isEmpty()) {
                return defaultValue;
            } else {
                return Double.parseDouble(str);
            }
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

     /**
     * Safely parses a string into a boolean value.
     *
     * @param str The string to parse.
     * @return The parsed boolean value or false if the string is null or not "true".
     */
    private boolean parseBooleanSafe(String str) {
        return str != null && str.equalsIgnoreCase("true");
    }

    /**
     * Exports a list of space objects with risk and orbit information to a CSV file.
     *
     * @param spaceObjects The list of space objects to export.
     */
    public void exportWithRiskAndOrbitInfo(List<SpaceObject> spaceObjects) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(newDataFile))) {
            writer.write("record_id,norad_cat_id,satellite_name,country,approximate_orbit_type,object_type,launch_year,launch_site,longitude,avg_longitude,geohash,HRR_Category,is_nominated,nominated_at,has_dossier,last_updated_at,justification,focused_analysis,days_old,conjunction_count,is_unk_object,all_maneuvers,days_since_ob,recent_maneuvers,deltaV_90day,has_sister_debris,still_in_orbit,risk_level");
            writer.newLine();
            for (SpaceObject listOfSpaceObject : spaceObjects) {
                    String row = String.join(",",
                    listOfSpaceObject.getRecord_id(),
                    listOfSpaceObject.getNorad_cat_id(),
                    listOfSpaceObject.getSatellite_name(),
                    listOfSpaceObject.getCountry(),
                    listOfSpaceObject.getApproximate_orbit_type(),
                    listOfSpaceObject.getObject_type(),
                    String.valueOf(listOfSpaceObject.getLaunch_year()),
                    listOfSpaceObject.getLaunch_site(),
                    String.valueOf(listOfSpaceObject.getLongitude()),
                    String.valueOf(listOfSpaceObject.getAvg_longitude()),
                    listOfSpaceObject.getGeohash(),
                    listOfSpaceObject.getHRR_Category(),
                    String.valueOf(listOfSpaceObject.isIs_nominated()),
                    listOfSpaceObject.getNominated_at(),
                    String.valueOf(listOfSpaceObject.isHas_dossier()),
                    listOfSpaceObject.getLast_updated_at(),
                    listOfSpaceObject.getJustification(),
                    String.join(";", listOfSpaceObject.getFocused_analysis()),
                    String.valueOf(listOfSpaceObject.getDays_old()),
                    String.valueOf(listOfSpaceObject.getConjunction_count()),
                    String.valueOf(listOfSpaceObject.isIs_unk_object()),
                    listOfSpaceObject.getAll_maneuvers(),
                    String.valueOf(listOfSpaceObject.getDays_since_ob()),
                    listOfSpaceObject.getRecent_maneuvers(),
                    String.valueOf(listOfSpaceObject.getDeltaV_90day()),
                    String.valueOf(listOfSpaceObject.isHas_sister_debris()),
                    String.valueOf(listOfSpaceObject.orbitStatus()),
                    listOfSpaceObject.setRiskType()
                );
    
                writer.write(row);
                writer.newLine();
            }
    
            System.out.println("Data has been stored to " + newDataFile +"\n");
        } catch (IOException e) {
            System.out.print("Error");
        }
    }


    /**
     * Logs a system interaction to the system log file.
     *
     * @param user The user initiating the interaction.
     * @param log_message The message to log.
     */
    public void logSystemInteraction(String user,  String log_message){

        try(BufferedWriter writer = new BufferedWriter(new FileWriter(systemLog,true))){

            LocalDateTime currentTime = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm:ss");
            String formatedDateTime = currentTime.format(formatter);

            String logEntry = String.format("[ " + formatedDateTime + "] " + user + " " + log_message , formatedDateTime);
            writer.write(logEntry);
            writer.newLine();

            System.out.print("\nLog Info Has Been Saved\n");

        } catch(IOException e){
            System.out.println("Error");
        }
    }

    /**
     * Analyzes and writes the count of in orbit vs. out of orbit space objects to a file.
     *
     * @param listOfSpaceObjects The list of space objects to analyze.
     */
    public void InVsOutOfOrbit(List<SpaceObject> listOfSpaceObjects){

        int inOrbitCount = 0;
        int outOfOrbitCount = 0;

        Scientist spaceObjectTracker = new Scientist();

        try(BufferedWriter writer = new BufferedWriter(new FileWriter(dataFileInOutOrbit))){

            for(SpaceObject spaceObjects : listOfSpaceObjects){
                if (spaceObjects.orbitStatus()){
                    inOrbitCount++;
                }else{
                    outOfOrbitCount++;
                }
            }

            writer.write("Number Of Objects That Are In Orbit: " + inOrbitCount);
            writer.newLine();
            writer.write("Number Of Objects That Are Out of Orbit: " + outOfOrbitCount);
            writer.newLine();
            writer.write("record_id,norad_cat_id,satellite_name,country,approximate_orbit_type,object_type,launch_year,launch_site,longitude,avg_longitude,geohash,HRR_Category,is_nominated,nominated_at,has_dossier,last_updated_at,justification,focused_analysis,days_old,conjunction_count,is_unk_object,all_maneuvers,days_since_ob,recent_maneuvers,deltaV_90day,has_sister_debris,still_in_orbit,risk_level");
            writer.newLine();

            List<SpaceObject> outOfOrbitObjects = spaceObjectTracker.getSpaceObjectsOutOfOrbit(listOfSpaceObjects);
            for (SpaceObject spaceObject : outOfOrbitObjects) {
                String row = String.join(",",
                    spaceObject.getRecord_id(),
                    spaceObject.getNorad_cat_id(),
                    spaceObject.getSatellite_name(),
                    spaceObject.getCountry(),
                    spaceObject.getApproximate_orbit_type(),
                    spaceObject.getObject_type(),
                    String.valueOf(spaceObject.getLaunch_year()),
                    spaceObject.getLaunch_site(),
                    String.valueOf(spaceObject.getLongitude()),
                    String.valueOf(spaceObject.getAvg_longitude()),
                    spaceObject.getGeohash(),
                    spaceObject.getHRR_Category(),
                    String.valueOf(spaceObject.isIs_nominated()),
                    spaceObject.getNominated_at(),
                    String.valueOf(spaceObject.isHas_dossier()),
                    spaceObject.getLast_updated_at(),
                    spaceObject.getJustification(),
                    String.join(";", spaceObject.getFocused_analysis()),
                    String.valueOf(spaceObject.getDays_old()),
                    String.valueOf(spaceObject.getConjunction_count()),
                    String.valueOf(spaceObject.isIs_unk_object()),
                    spaceObject.getAll_maneuvers(),
                    String.valueOf(spaceObject.getDays_since_ob()),
                    spaceObject.getRecent_maneuvers(),
                    String.valueOf(spaceObject.getDeltaV_90day()),
                    String.valueOf(spaceObject.isHas_sister_debris()),
                    String.valueOf(spaceObject.orbitStatus()),
                    spaceObject.setRiskType()
                );
    
                writer.write(row);
                writer.newLine();
            }

        } catch(IOException e){
            System.out.print("Error");
        }
    }
}
