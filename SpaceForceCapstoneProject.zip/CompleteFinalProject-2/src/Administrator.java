package src;

/**
 * Represents an Administrator in the Space Debris Management System.
 * This class is currently under development and will contain functionality
 * for creating, manage, and delete users in the system.
 * @author Damien Muro
 * @author Ethan Patin
 * @author Christian Parra
 * @version Version 3.0
 */
public class Administrator {
    private final UserLogin userLogin;

    /**
     * Constructs an Administrator instance with specified UserLogin instance.
     * @param userLogin The instance for user management operations.
     */
    public Administrator(UserLogin userLogin){
        this.userLogin = userLogin;
    }


    /**
     * Creates a new user in the system.
     */
    public void createUser(){
        userLogin.createUser();
    }

    /**
     * Manages user information in the system.
     */
    public void manageUser(){
        userLogin.updateUserInfo();
    }

    /**
     * Deletes a user from the system.
     */
    public void deleteUser(){
        userLogin.deleteUser();
    }


}
