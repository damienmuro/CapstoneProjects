package src;
public class ObjectTypeNotFoundException extends Exception{

    public ObjectTypeNotFoundException(String message){
        super(message);
    }
    
}
