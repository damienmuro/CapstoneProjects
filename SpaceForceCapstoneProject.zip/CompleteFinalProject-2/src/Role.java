package src;

/**
 * Interface for role-specific menu implementations.
 *
 * @author Damien Muro
 * @author Ethan Patin
 * @author Christian Parra
 * @version Version 1.0
 */
public interface Role {

    /**
     * Displays the menu specific to a user role.
     * Each implementing class should define the menu structure and functionality
     * based on the role's responsibilities and permissions.
     */
    void showMenu();
    
}
