package src;

/**
 * Main entry point for the Space Debris Management System.
 * It initializes and invokes the main menu of the application, allowing users to interact
 * with the system based on their role.
 *
 * @author Damien Muro
 * @author Ethan Patin
 * @author Christian Parra
 * @version 2.0
 */
public class RunSimulation {

    /**
     * Starts the application.
     * It calls mainMenu() method to display the main menu.
     * @param args Command line arguments.
     */
    public static void main(String[] args){
        MainMenu.mainMenu();
    }
    
}
