package src;

/**
 * Represents a user in the system.
 * This class encapsulates the user's details, including their username, password, and role.
 *
 * @author Damien Muro
 * @author Ethan Patin
 * @author Christian Parra
 * @version Version 1.0
 */
public class User {
    private String userName; 
    private String password;
    private String userRole;

    /**
     * Constructs a new User with the specified username, password, and role.
     *
     * @param userName The username of the user.
     * @param password The password of the user.
     * @param userRole The role of the user (Admin, Scientist, and Representative).
     */
    public User(String userName, String password, String userRole){
        this.userName = userName;
        this.password = password;
        this.userRole = userRole;
    }

    /**
     * Retrieves the username of the user.
     * @return The username of the user.
     */
    public String getUserName(){
        return userName;
    }

    /**
     * Retrieves the password of the user.
     * @return The password of the user.
     */
    public String getPassword(){
        return password;
    }

    /**
     * Retrieves the role of the user.
     * @return The role of the user.
     */
    public String getUserRole(){
        return userRole;
    }

    /**
     * Sets the username of the user.
     * @param userName The username to be set.
     */
    public void setUserName(String userName){
        this.userName = userName;
    }

    /**
     * Sets the password of the user.
     * @param password The password to be set.
     */
    public void setPassword(String password){
        this.password = password;
    }

    /**
     * Sets the role of the user.
     * @param userRole The role to be set.
     */
    public void setUserRole(String userRole){
        this.userRole = userRole;
    }
}
