package src;
/**
 * Represents a Policymaker in the Space Debris Management System.
 * This class is currently under development and will contain functionality
 * for reviewing reports and assessing risk levels.
 * @author Damien Muro
 * @author Ethan Patin
 * @author Christian Parra
 * @version Version 1.0
 */
public class PolicyMaker {
    
}
