package src;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Manages user login and account operations, including user creation, login, deletion, and updates.
 *
 * @author Damien Muro
 * @author Ethan Patin
 * @author Christian Parra
 * @version Version 1.0
 */
public class UserLogin {

    private List<User> users;
    private String userFileLog = "UserLoginInfo.csv";

    /**
     * Constructs UserLogin and loads users.
     */
    public UserLogin(){
        users = new ArrayList<>();
        loadUsers();
    }

    /**
     * Loads users from user file.
     * If the file does not exist, a new file is created with a default administrator user.
     */
    public void loadUsers(){
        File file = new File(userFileLog);

        if(!file.exists()){
            User owner = new User("Owner", "123", "Administrator");
            users.add(owner);
            saveUserToFile(owner);
            return;
        }
        try(BufferedReader reader = new BufferedReader(new FileReader(userFileLog))){
            String line = reader.readLine();

            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",", -1);
                
                String userName = data[0];
                String password = data[1];
                String userRole = data[2];
                
                User new_user = new User(userName, password, userRole);
                users.add(new_user);
            }

        }catch(FileNotFoundException e){
            System.out.println("A New User Info File Will Be Created\n");

        }
        
        
        catch(IOException e){
            e.printStackTrace();
        }
    }

    /**
     * Checks if a username already exists in the system.
     *
     * @param user_name The username to check.
     * @return true if the username exists, false otherwise.
     */
    public boolean userExists(String user_name){
        for (User currentUser : users){
            if(currentUser.getUserName().equals(user_name)){
                return true; 
            }
        }

        return false;
    }

    /**
     * Validates a password against a defined pattern.
     * The password must contain at least one lowercase letter, one uppercase letter, one digit, and one special character.
     *
     * @param password The password to validate.
     * @return true if the password matches the pattern, false otherwise.
     */
    public boolean validPassword(String password){
        String pattern = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&#_]).+$";
        return password.matches(pattern);
    }

    /**
     * Prompts the user to create a new account with a username, password, and role.
     * Ensures the username is unique and the password meets the validation criteria.
     */
    public void createUser(){
        Scanner user_info_input = new Scanner(System.in);
        System.out.print("Please Enter A Username: ");
        String user_name = user_info_input.nextLine();

        while(userExists(user_name)){
            System.out.println("\nThat Username Is Taken. Please Enter A Different One\n");
            System.out.print("Please Enter A User Name: ");
            user_name = user_info_input.nextLine();
        }

        System.out.print("Please Enter A Password (Must Include At Least One Digit,Upper Case, Lower Case, Symbol) : ");
        String password = user_info_input.nextLine();

        while(!validPassword(password)){
            System.out.println("\nThat Password Is Not Valid. Please Enter A Different One");
            System.out.print("Please Enter A Password: ");
            password = user_info_input.nextLine();
        }

        String role; 
        while(true){
            System.out.print("Please Enter A Role: ");
            role = user_info_input.nextLine();

            if(RoleFactory.isValidRole(role)){
                break;
            }

            System.out.println("\nInvalid Role Try Again\n");
        }
        

        User newUser = new User(user_name, password, role);
        users.add(newUser);
        saveUserToFile(newUser);

        System.out.println("\nUser '" + user_name + "' with role '" + role + "' has been created successfully.\n");


    }

    /**
     * Saves a single user's information to the CSV file.
     * @param user The user to save.
     */
    public void saveUserToFile(User user){
        File file = new File(userFileLog);
        boolean fileExists = file.exists();
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(userFileLog, true))){
            if (!fileExists){
                writer.write("Username, Password, Role");
                writer.newLine();

            }
            
            writer.write(user.getUserName() + "," + user.getPassword() + "," + user.getUserRole()); 
            writer.newLine();

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     * Allows the user to update their account information, including username, password, and role.
     * Validates the current credentials before making changes.
     */
    public void updateUserInfo() {
        Scanner user_info_input = new Scanner(System.in);
        
        System.out.print("Enter The Users Current Username: ");
        String currentUserName = user_info_input.nextLine();
    
        System.out.print("Enter The Users Current Password: ");
        String currentPassword = user_info_input.nextLine();
    
        for (User currentUser : users) {
            if (currentUser.getUserName().equals(currentUserName) && currentUser.getPassword().equals(currentPassword)) {
                System.out.println("\nYou Have Been Authorized To Make Changes To This Account\n");
    
                System.out.println("Which Part Of The Account Would You Like To Alter?");
                System.out.println("1. Username");
                System.out.println("2. Password");
                System.out.println("3. Role");
    
                String option = user_info_input.nextLine();
    
                switch (option) {
                    case "1":
                        System.out.println("Enter The New Username: ");
                        String newUsername = user_info_input.nextLine();
                        if (userExists(newUsername)) {
                            System.out.println("Name Has Been Taken Already\n");
                            return;
                        }
                        currentUser.setUserName(newUsername);
                        break;
    
                    case "2":
                        System.out.println("Enter The New Password: ");
                        String newPassword = user_info_input.nextLine();
                        if (!validPassword(newPassword)){
                            System.out.println("That Is Not A Valid Password\n");
                            return;
                        }
                        currentUser.setPassword(newPassword);
                        break;
    
                    case "3":
                        System.out.println("Enter The New Role: ");
                        String newRole = user_info_input.nextLine();
                        if (!RoleFactory.isValidRole(newRole)) {
                            System.out.println("Not A Valid Role\n");
                            return;
                        }
                        currentUser.setUserRole(newRole);
                        break;
    
                    default:
                        System.out.println("Invalid Option\n");
                        return;
                }
    
                saveAllUsersToFile();
                System.out.println("Updated Info\n");
                return;
            }
        }
    
        System.out.println("\nFailed: Incorrect Username or Password");
    }

    /**
     * Saves all users' information to the CSV file, overwriting any existing data.
     */
    public void saveAllUsersToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(userFileLog))) {
            writer.write("Username, Password, Role");
            writer.newLine();
            for (User user : users) {
                writer.write(user.getUserName() + "," + user.getPassword() + "," + user.getUserRole());
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Authenticates a user by prompting them for a username and password.
     * If the credentials are valid, the user is successfully logged in.
     *
     * @return The logged-in user object, or null if authentication fails.
     */
    public User login(){
        Scanner user_info_input = new Scanner(System.in);
        System.out.print("Please Enter Your User Name: ");
        String user_name = user_info_input.nextLine();
        System.out.print("Please Enter Your Password: ");
        String password = user_info_input.nextLine();


        for (User user : users){
            if(user.getUserName().equals(user_name) && user.getPassword().equals(password)){
                System.out.println("\nLogin Successful! Welcome " + user_name + " You Have Been Successfully Logged In As " + user.getUserRole());
                return user;
            }
        }

        System.out.println("\nLogin Has Failed. Check Your User Name Or Password");
        return null;
    }

    /**
     * Deletes a user from the system after validating their credentials.
     * Updates the CSV file to reflect the deletion.
     */
    public void deleteUser() {
        Scanner user_info_input = new Scanner(System.in);
    
        System.out.println("\nDeleting A User. Please Enter Their Credentials\n");
        System.out.print("Enter Their Username: ");
        String usernameToDelete = user_info_input.nextLine();
    
        System.out.print("Enter Their Password: ");
        String passwordToDelete = user_info_input.nextLine();
    
        System.out.print("Enter Their Role: ");
        String roleToDelete = user_info_input.nextLine();
    
        boolean userDeleted = false;
    
        for(User currentUser : users){
            if(currentUser.getUserName().equals(usernameToDelete) && currentUser.getPassword().equals(passwordToDelete) && currentUser.getUserRole().equals(roleToDelete)){
                users.remove(currentUser);
                userDeleted = true;
                break;
            }
        }
    
        if (!userDeleted) {
            System.out.println("\nUser Not Found.");
            return;
        }
    
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(userFileLog))) {
            writer.write("Username, Password, Role");
            writer.newLine();
            for (User user : users) {
                writer.write(user.getUserName() + "," + user.getPassword() + "," + user.getUserRole());
                writer.newLine();
            }
            System.out.println("User Has Been Deleted.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    

    
    
}
