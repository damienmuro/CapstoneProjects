package src;
import java.util.Scanner;

/**
 * Implements the Role interface for Administrator users.
 *
 * @author Damien Muro
 * @author Ethan Patin
 * @author Christian Parra
 * @version Version 1.0
 */
public class AdministratorRole implements Role{
    private final Scanner scanner = new Scanner(System.in);
    private final String username; 
    private final String role;
    private final Administrator administrator;
    private final SpaceObjectsFileManager spaceObjectsFileManager = new SpaceObjectsFileManager();


    /**
     * Constructs an AdministratorRole with credentials and UserLogin.
     *
     * @param username The administrator's username.
     * @param role The administrator's role.
     * @param sharedUserLogin The shared UserLogin instance.
     */
    public AdministratorRole(String username, String role, UserLogin sharedUserLogin){
        this.username = username;
        this.role = role;
        this.administrator = new Administrator(sharedUserLogin);
    }

    /**
     * Displays the administrator menu and handles user input to perform administrative tasks.
     * Menu includes options for creating, managing, and deleting users as well as logging out.
     */
    public void showMenu(){
        String userLabel = username + " (" + role.toUpperCase() + ")";
        while(true){
            System.out.println("\nCurrently Logged On As " + username + ":\n");
            System.out.println("===Administrator Menu===");
            System.out.println("1. Create User");
            System.out.println("2. Manage User");
            System.out.println("3. Delete User");
            System.out.println("4. Log Out\n");
            System.out.print("Select Option From The Given List: ");

            String option = scanner.nextLine();
            switch (option) {
                case "1":
                    spaceObjectsFileManager.logSystemInteraction(userLabel, "Has Chosen To Create A New User ");
                    System.out.print("\nCreating New User. Enter The Desired Credentials\n");
                    administrator.createUser();
                    
                    break;
                case "2":
                    spaceObjectsFileManager.logSystemInteraction(userLabel, "Has Chosen To Manage A Users Data ");
                    administrator.manageUser();
                    break;
                case "3":
                    spaceObjectsFileManager.logSystemInteraction(userLabel, "Has Chosen To Delete A Users Data ");
                    administrator.deleteUser();
                    break;
                case "4":
                    spaceObjectsFileManager.logSystemInteraction(userLabel, "Has Logged Out ");
                    System.out.println("Returning to the main menu. Logging out...");
                    return;
            }
        }
    }

}
