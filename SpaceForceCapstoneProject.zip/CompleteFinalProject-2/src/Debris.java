package src;
/**
 * Represents a Debris object in the Space Debris Management System.
 * Extends the SpaceObject class and provides additional functionality
 * specific to managing and assessing debris in orbit.
 * @author Damien Muro
 * @author Ethan Patin
 * @author Christian Parra
 * @version Version 3.0
 */
public class Debris extends SpaceObject {

    final int MAX_DAYS = 15000;
    final int MAX_CONJUNCTION_COUNT = 1;

    /**
     * Constructs a new Debris object with the specified parameters.
     *
     * @param record_id Unique identifier for the satellite record.
     * @param norad_cat_id NORAD catalog ID.
     * @param satellite_name Name of the satellite.
     * @param country Country of origin.
     * @param approximate_orbit_type Type of orbit (LEO, MEO, GEO, HEO).
     * @param object_type Type of space object.
     * @param launch_year Year of launch.
     * @param launch_site Launch site location.
     * @param longitude Current longitude.
     * @param avg_longitude Average longitude.
     * @param geohash Geohash location.
     * @param HRR_Category High Risk Resident category.
     * @param is_nominated Whether the object is nominated for tracking.
     * @param nominated_at Date when nominated.
     * @param has_dossier Whether a dossier exists.
     * @param last_updated_at Last update timestamp.
     * @param justification _
     * @param focused_analysis Array of focused analysis points.
     * @param days_old Age in days.
     * @param conjunction_count Number of conjunctions.
     * @param is_unk_object Whether object is unknown.
     * @param all_maneuvers All maneuver data.
     * @param days_since_ob Days since last observation.
     * @param recent_maneuvers Recent maneuver data.
     * @param deltaV_90day Delta V over 90 days.
     * @param has_sister_debris Whether sister debris exists.
     */
    public Debris(String record_id, String norad_cat_id, String satellite_name, String country, String approximate_orbit_type,
                  String object_type, int launch_year, String launch_site, double longitude, double avg_longitude,
                  String geohash, String HRR_Category, boolean is_nominated, String nominated_at, boolean has_dossier,
                  String last_updated_at, String justification, String[] focused_analysis, int days_old, long conjunction_count,
                  boolean is_unk_object, String all_maneuvers, int days_since_ob, String recent_maneuvers, double deltaV_90day,
                  boolean has_sister_debris) {
        super(record_id, norad_cat_id, satellite_name, country, approximate_orbit_type, object_type, launch_year, launch_site,
              longitude, avg_longitude, geohash, HRR_Category, is_nominated, nominated_at, has_dossier, last_updated_at,
              justification, focused_analysis, days_old, conjunction_count, is_unk_object, all_maneuvers, days_since_ob,
              recent_maneuvers, deltaV_90day, has_sister_debris);
    }

    /**
     * Returns a string representation of the debris.
     * @return String containing all debris information.
     */
    @Override
   public String toString() {
        return String.join(",",
            getRecord_id(),
            getNorad_cat_id(),
            getSatellite_name(),
            getCountry(),
            getApproximate_orbit_type(),
            getObject_type(),
            String.valueOf(getLaunch_year()),
            getLaunch_site(),
            String.valueOf(getLongitude()),
            String.valueOf(getAvg_longitude()),
            getGeohash(),
            getHRR_Category(),
            String.valueOf(isIs_nominated()),
            getNominated_at(),
            String.valueOf(isHas_dossier()),
            getLast_updated_at(),
            getJustification(),
            String.join(";", getFocused_analysis()),
            String.valueOf(getDays_old()),
            String.valueOf(getConjunction_count()),
            String.valueOf(isIs_unk_object()),
            getAll_maneuvers(),
            String.valueOf(getDays_since_ob()),
            getRecent_maneuvers(),
            String.valueOf(getDeltaV_90day()),
            String.valueOf(isHas_sister_debris())
        );
    } 


    /**
     * Checks if the orbit type is valid.
     * @return true if orbit type is LEO, MEO, HEO, or GEO, false otherwise.
     */
    public boolean validOrbitType() {
        String orbitType = getApproximate_orbit_type();
        if (orbitType == null || orbitType.equalsIgnoreCase("Unknown Orbit Category")) {
            return false;
        }
        if (orbitType.equalsIgnoreCase("LEO") || orbitType.equalsIgnoreCase("MEO") || orbitType.equalsIgnoreCase("HEO") || orbitType.equalsIgnoreCase("GEO")) {
            return true;
        }

        return false;
    }


    /**
     * Determines the risk type based on orbital drift.
     * @return "High Risk", "Moderate Risk", or "Low Risk" based on drift thresholds.
     */
    public String riskType() {
        double orbital_drift = Math.abs(getLongitude() - getAvg_longitude());
        String risk = "";

        if (orbital_drift > MAX_DAYS) {
            risk = "High Risk";
        } else if (orbital_drift > MAX_CONJUNCTION_COUNT) {
            risk = "Moderate Risk";
        } else {
            risk = "Low Risk";
        }

        return risk;
    }

    /**
     * Checks if the debris has a valid orbit status.
     * @return true if orbit type is valid, false otherwise.
     */
    @Override
    public boolean orbitStatus() {
        return validOrbitType();
    }

    /**
     * Sets and returns the risk type for the debris.
     * @return the calculated risk type.
     */
    @Override
    public String setRiskType() {
        return riskType();
    }

    
}
