package src;
import java.util.List;
import java.util.Scanner;


/**
 * Handles the main menu and role selection for the system.
 * It provides a role-based login system where users can log in as a Scientist,
 * Space Agency Representative, Policymaker, or Administrator, and access their respective menus.
 *
 * @author Damien Muro
 * @author Ethan Patin
 * @author Christian Parra
 * @version Version 2.0
 */
public class MainMenu {

    /**
     * Displays the main menu for the Space Debris Management System.
     * Users can log in to their respective roles and perform role-specific tasks.
     * The system also allows users to exit, saving all relevant data before termination.
     */
    public static void mainMenu() {
        UserLogin userLogin = new UserLogin();
        Scanner scanner = new Scanner(System.in);
        final SpaceObjectsFileManager spaceObjectsFileManager = new SpaceObjectsFileManager();
        final List<SpaceObject> debrisList = spaceObjectsFileManager.loadSpaceObjects("rso_metrics_columns_jumbled.csv");


        while (true) {
            System.out.println("\n==== Role Selection Menu ====");
            System.out.println("1. Scientist");
            System.out.println("2. Space Agency Representative");
            System.out.println("3. Policymaker");
            System.out.println("4. Administrator");
            System.out.println("Type EXIT To Exit The System\n");
            System.out.print("Select Option From The Given List: ");
            String choice = scanner.nextLine();

            User loggedInUser;

            switch (choice) {
                case "1":
                    System.out.println("\n==== Scientist Login ====");
                    loggedInUser = userLogin.login();
                    if (loggedInUser != null && loggedInUser.getUserRole().equalsIgnoreCase("scientist")) {
                        Role role = RoleFactory.getRole(loggedInUser, userLogin);
                        if (role != null) role.showMenu();
                    } 
                    break;

                case "2":
                    System.out.println("\n==== Space Agency Representative Login ====");
                    loggedInUser = userLogin.login();
                    if (loggedInUser != null && loggedInUser.getUserRole().equalsIgnoreCase("space agency representative")) {
                        Role role = RoleFactory.getRole(loggedInUser, userLogin);
                        if (role != null) role.showMenu();
                    }
                    break;

                case "3":
                    System.out.println("\n==== Policymaker Login ====");
                    loggedInUser = userLogin.login();
                    if (loggedInUser != null && loggedInUser.getUserRole().equalsIgnoreCase("policymaker")) {
                        Role role = RoleFactory.getRole(loggedInUser, userLogin);
                        if (role != null) role.showMenu();
                        else System.out.println("Failed to load Policymaker role.");
                    } else {
                        System.out.println("Invalid login or not a Policymaker.");
                    }
                    break;

                case "4":
                    System.out.println("\n==== Administrator Login ====");
                    loggedInUser = userLogin.login();
                    if (loggedInUser != null && loggedInUser.getUserRole().equalsIgnoreCase("administrator")) {
                        Role role = RoleFactory.getRole(loggedInUser, userLogin);
                        if (role != null) {
                            role.showMenu();
                        }
                         else {
                        System.out.println("Invalid login or not an Administrator.");
                        }
                    }
                    break;

                case "EXIT":
                    System.out.println("Data Will Be Saved...");
                    spaceObjectsFileManager.exportWithRiskAndOrbitInfo(debrisList);
                    spaceObjectsFileManager.logSystemInteraction("User", "Has Exited The System. Saving Data...");
                    
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;

                default:
                    System.out.println("\nInvalid option. Please try again.");
                    break;
            }
        }

    }
}
