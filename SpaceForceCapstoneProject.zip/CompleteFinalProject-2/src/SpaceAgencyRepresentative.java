package src;
import java.util.ArrayList;
import java.util.List;
/**
 * Represents a Space Agency Representative in the Space Debris Management System.
 * This class is currently under development and will include functionality
 * for analyzing long-term impacts and generating density reports of space objects.
 * @author Damien Muro
 * @author Ethan Patin
 * @author Christian Parra
 * @version Version 3.0
 */
public class SpaceAgencyRepresentative implements SpaceObjectTracker, SpaceAgencyRepresentativeSpaceObjectTracker {

    public final int MAX_DAYS_OLD = 200;
    public final int MAX_CONJUNCTION_COUNT = 0;
    private final String target_approximate_orbit_type = "LEO";

    /**
     * Retrieves space objects in Low Earth Orbit (LEO).
     *
     * @param spaceObjects List of space objects to filter.
     * @return A list of space objects in Low Earth Orbit (LEO).
     */
    public List<SpaceObject> getSpaceObjectsLEO(List<SpaceObject> spaceObjects){
        List<SpaceObject> matchedLEO = new ArrayList<>();
    
        for (SpaceObject currentSpaceObject : spaceObjects){
            if (currentSpaceObject.getApproximate_orbit_type().equalsIgnoreCase(target_approximate_orbit_type)){
                matchedLEO.add(currentSpaceObject);
            }
        }
    
        return matchedLEO;
    }
    
    /**
     * Analyzes the long-term impact objects.
     *
     * @param spaceObjects List of space objects to analyze.
     * @return A list of space objects with significant long-term impacts.
     */
    public List<SpaceObject> analyzeLongTermImpact(List<SpaceObject> spaceObjects) {
        List<SpaceObject> longTermImpactObjects = new ArrayList<>();
        
        List<SpaceObject> leoObjects = getSpaceObjectsLEO(spaceObjects);
        
        if (leoObjects.isEmpty()) {
            System.out.println("No LEO objects found.");
        }
        
        for (SpaceObject currentSpaceObject : leoObjects) {

            if (currentSpaceObject.getDays_old() > MAX_DAYS_OLD && currentSpaceObject.getConjunction_count() > MAX_CONJUNCTION_COUNT) {
                longTermImpactObjects.add(currentSpaceObject);
            }
        }
        
        return longTermImpactObjects;
    }
    
    /**
     * Gets objects in longitude range.
     *
     * @param min_longitude Minimum longitude of the range.
     * @param max_longitude Maximum longitude of the range.
     * @param spaceObjects List of space objects to filter.
     * @return A list of space objects within the specified longitude range.
     */
    public List<SpaceObject> getObjectsInLongitudeRange(double min_longitude, double max_longitude, List<SpaceObject> spaceObjects) {
        List<SpaceObject> space_objects_in_range = new ArrayList<>();
        for (SpaceObject currentObject : spaceObjects) {
            if (currentObject.getLongitude() > min_longitude && currentObject.getLongitude() <= max_longitude) {
                space_objects_in_range.add(currentObject);
            }
        }
        return space_objects_in_range;
    }

    /**
     * Generates a density report for the given range of space objects.
     *
     * @param spaceObjects_in_range List of space objects within the range.
     * @return The count of valid objects within the range.
     */
    public int generateDenistyReportCount(List<SpaceObject> spaceObjects_in_range){
        int valid_objects_count = 0;

        for(int i = 0; i < spaceObjects_in_range.size(); i++){
            valid_objects_count++;
        }

        System.out.println("\n---Number Of SpaceObjects Within The Given Range: " + valid_objects_count +" ---");
        return valid_objects_count;
    }


}