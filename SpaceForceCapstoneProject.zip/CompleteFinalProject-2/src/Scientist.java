package src;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a Scientist role in the Space Debris Management System.
 * Provides methods for analyzing and tracking space objects.
 * @author Damien Muro
 * @author Ethan Patin
 * @author Christian Parra
 * @version Version 3.0
 */
public class Scientist implements SpaceObjectTracker, ScientistSpaceObjectTracker {

    private final String target_approximate_orbit_type = "LEO";

    /**
     * Retrieves space objects of a specific type.
     *
     * @param spaceObjects List of space objects to filter.
     * @param object_type The type of object to filter by.
     * @return List of space objects matching the specified type.
     */
    public List<SpaceObject> getObjectTypes(List<SpaceObject> spaceObjects, String object_type){
        List<SpaceObject> matchedObjectType = new ArrayList<>();

        System.out.println("record_id,norad_cat_id,satellite_name,country,approximate_orbit_type,object_type,launch_year,launch_site,longitude,avg_longitude,geohash,HRR_Category,is_nominated,nominated_at,has_dossier,last_updated_at,justification,focused_analysis,days_old,conjunction_count,is_unk_object,all_maneuvers,days_since_ob,recent_maneuvers,deltaV_90day,has_sister_debris,still_in_orbit,risk_level");
        for(SpaceObject currentSpaceObject: spaceObjects){
            if(currentSpaceObject.getObject_type().equalsIgnoreCase(object_type)){
                matchedObjectType.add(currentSpaceObject);
            }
        }

        return matchedObjectType;
    }


    /**
     * Retrieves space objects in Low Earth Orbit (LEO).
     *
     * @param spaceObjects List of space objects to filter.
     * @return List of space objects in the specified orbit.
     */
    public List<SpaceObject> getSpaceObjectsLEO(List<SpaceObject> spaceObjects){
        List<SpaceObject> matchedLEO = new ArrayList<>();

        for (SpaceObject currentSpaceObject: spaceObjects){
            if(currentSpaceObject.getApproximate_orbit_type().equalsIgnoreCase(target_approximate_orbit_type)){
                matchedLEO.add(currentSpaceObject);
            }
        }

        return matchedLEO;
    }

    /**
     * Gets space objects out of orbit.
     *
     * @param spaceObjects List to filter.
     * @return Objects not in orbit.
     */
    public List<SpaceObject> getSpaceObjectsOutOfOrbit(List<SpaceObject> spaceObjects){
        List<SpaceObject> matchedOutOfOrbit = new ArrayList<>();

        for (SpaceObject currentSpaceObject : spaceObjects){
            if(!currentSpaceObject.orbitStatus()){
                matchedOutOfOrbit.add(currentSpaceObject);
            }
        }

        return matchedOutOfOrbit;
    }

}






