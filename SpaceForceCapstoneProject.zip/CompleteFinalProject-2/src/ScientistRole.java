package src;
import java.util.List;
import java.util.Scanner;

/**
 * Implements Role interface for Scientist users.
 *
 * @author Damien Muro
 * @author Ethan Patin
 * @author Christian Parra
 * @version Version 1.0
 */
public class ScientistRole implements Role {
    private final Scanner scanner = new Scanner(System.in);
    private final SpaceObjectsFileManager spaceObjectsFileManager = new SpaceObjectsFileManager();
    private final List<SpaceObject> debrisList = spaceObjectsFileManager.loadSpaceObjects("rso_metrics_columns_jumbled.csv");
    private final Scientist scientist = new Scientist();

    private final String username; 
    private final String role;


    /**
     * Constructs a ScientistRole with credentials.
     *
     * @param username The scientist's username
     * @param role The scientist's role
     */
    public ScientistRole(String username, String role){
        this.username = username;
        this.role = role;
    }


    /**
     * Displays the Scientist-specific menu and allows the user to select options
     * for tracking objects in space, assessing orbit status, or logging out.
     */
    public void showMenu(){
        String userLabel = username + " (" + role.toUpperCase() + ")";
        spaceObjectsFileManager.logSystemInteraction(userLabel, "Has Logged Into The Role SCIENTIST");

        while(true){
            System.out.println("\nCurrently Logged On As " + username + ":\n");
            System.out.println("==== Scientist Menu ====");
            System.out.println("1. Track Objects in Space");
            System.out.println("2. Assess Orbit Status");
            System.out.println("3. LogOut\n");
            System.out.print("Select Option From The Given List: ");
            String option = scanner.nextLine(); 

            switch(option){
                case "1":
                    trackObjectsMenu();
                    break;
                case "2":
                    assessOrbitMenu();
                    break;
                case "3":
                    spaceObjectsFileManager.logSystemInteraction(userLabel, "Has Logged Out ");
                    System.out.println("Returning to the main menu. Logging out...");
                    return;
            }
        }
    }


    /**
     * Displays the menu for tracking objects in space and allows the user to
     * select specific object types for tracking.
     */
    public void trackObjectsMenu(){
        String userLabel = username + " (" + role.toUpperCase() + ")";
        spaceObjectsFileManager.logSystemInteraction(userLabel, "Tracked Objects in Space");

        System.out.println("\n====Select An Object In Space To Track====");
        System.out.println("1. Rocket Body");
        System.out.println("2. Debris");
        System.out.println("3. Payload");
        System.out.println("4. Unknown");
        System.out.println("5. Back\n");
        System.out.print("Select Option From The Given List: ");

        String option = scanner.nextLine();

        switch(option){
            case "1":
                trackSpaceObjectType("Rocket Body");
                break;
            case "2":
                trackSpaceObjectType("Debris");
                break;
            case "3":
                trackSpaceObjectType("Payload");
                break;
            case "4":
                trackSpaceObjectType("Unknown");
                break;
            case "5":
                return;
        }
    }

    /**
     * Tracks space objects of a specific type and displays the details of the tracked objects.
     * @param type The object type to track.
     */
    public void trackSpaceObjectType(String type){
        String userLabel = username + " (" + role.toUpperCase() + ")";
        spaceObjectsFileManager.logSystemInteraction(userLabel, "Selected To Track " + type);
        List<SpaceObject> spaceObjects = scientist.getObjectTypes(debrisList, type);
        System.out.println("\n--- " + type + " Found ---");
        for (SpaceObject currentSpaceObject : spaceObjects) {
            System.out.println(currentSpaceObject);
        }
        spaceObjectsFileManager.logSystemInteraction(userLabel, "Gathered a List of Objects With Type " + type + ".");
    }

    /**
     * Displays the menu for assessing orbit status and allows the user to
     * select options for tracking objects in Low Earth Orbit (LEO) or
     * assessing if debris is still in orbit.
     */
    public void assessOrbitMenu(){
        String userLabel = username + " (" + role.toUpperCase() + ")";
        spaceObjectsFileManager.logSystemInteraction(userLabel, "Assesed Orbit Status");

        System.out.println("\n====Assess Orbit Status====");
        System.out.println("1. Track Objects in LEO");
        System.out.println("2. Assess If Debris Is Still In Orbit");
        System.out.println("3. Back\n");
        System.out.print("Select Option From The Given List: ");

        String option = scanner.nextLine();

        switch(option){
            case "1":
                assessOrbitLEO();
                break;
            case "2":
                spaceObectsInVsOutOfOrbit();
                break;
            case "3":
                return;
        }
    }

    /**
     * Tracks and displays objects located in Low Earth Orbit (LEO).
     */
    public void assessOrbitLEO(){
        String userLabel = username + " (" + role.toUpperCase() + ")";
        spaceObjectsFileManager.logSystemInteraction(userLabel, "Tracked Objects in LEO");

        List<SpaceObject> leoObjects = scientist.getSpaceObjectsLEO(debrisList);
        System.out.println("\n--- Selected Option: Track Objects in LEO ---");
        System.out.println("\n--- List Of SpaceObjects In The LEO ---\n");
        for (SpaceObject currentSpaceObject : leoObjects) {
            System.out.println(currentSpaceObject);
        }
        spaceObjectsFileManager.logSystemInteraction(userLabel, "Gathered a List of Objects in LEO");
    }

    /**
     * Assesses debris that is still in orbit vs. debris that has exited orbit.
     */
    public void spaceObectsInVsOutOfOrbit(){
        String userLabel = username + " (" + role.toUpperCase() + ")";
        spaceObjectsFileManager.logSystemInteraction(userLabel, "Assessed If Debris Is Still In Orbit");
        System.out.println("\n--- Selected Option: Assess If Debris Is Still In Orbit ---\n");

        spaceObjectsFileManager.exportWithRiskAndOrbitInfo(debrisList);
        spaceObjectsFileManager.logSystemInteraction(userLabel, "Data Saved To A CSV With The New Updated Info Of still_in_Orbit And risk_level.");

        spaceObjectsFileManager.InVsOutOfOrbit(debrisList);
        spaceObjectsFileManager.logSystemInteraction(userLabel, "Data Saved To A New TXT With New Updated Data of In Orbit Vs. Exited Debris And A List Of Exited Debris.");
    }

}
