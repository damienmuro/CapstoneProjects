package src;
import java.util.List;

    /**
     * Interface that is meant for tracking and filtering space objects based on various criteria such as object type,
     * orbit type, and orbit status.
     * @author Damien Muro
     * @author Ethan Patin
     * @author Christian Parra
     * @version Version 3.0
     */
    public interface SpaceObjectTracker {



    /**
     * Filters the list of space objects to include only those in the specified orbit type.
     *
     * @param spaceObjects The list of space objects to filter.
     * @return A list of instances in the specified orbit type.
     */
    public List<SpaceObject> getSpaceObjectsLEO(List<SpaceObject> spaceObjects);


}
    
    /**
     * Interface for scientist-specific tracking.
     */
    interface ScientistSpaceObjectTracker {
    

    /**
     * Filters the list of space objects to include only those that match the specified object type.
     *
     * @param spaceObjects The list of space objects to filter.
     * @param object_type  The type of object to filter.
     * @return A list matching space objects.
     * @throws ObjectTypeNotFoundException
     */
    public List<SpaceObject> getObjectTypes(List<SpaceObject> spaceObjects, String object_type) throws ObjectTypeNotFoundException;
    
    /**
     * Filters space objects that are out of orbit.
     *
     * @param spaceObjects List of space objects to filter.
     * @return List of space objects not in orbit.
     */
    public List<SpaceObject> getSpaceObjectsOutOfOrbit(List<SpaceObject> spaceObjects);
}

/**
 * Interface for representative-specific tracking.
 */
    interface SpaceAgencyRepresentativeSpaceObjectTracker {
    
    /**
     * Analyzes the long-term impact of space objects based on specific criteria.
     *
     * @param spaceObjects The list of space objects to analyze.
     * @return A list of space objects with significant long-term impacts.
     */
        public List<SpaceObject> analyzeLongTermImpact(List<SpaceObject> spaceObjects);

    /**
     * Filters space objects that fall within a specified longitude range.
     *
     * @param min_longitude The minimum longitude of the range.
     * @param max_longitude The maximum longitude of the range.
     * @param spaceObjects  The list of space objects to filter.
     * @return A list of space objects within the specified longitude range.
     */
        public List<SpaceObject> getObjectsInLongitudeRange(double min_longitude, double max_longitude, List<SpaceObject> spaceObjects);
    }
    




    
