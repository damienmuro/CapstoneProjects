package src;
import java.util.List;
import java.util.Scanner;

/**
 * Implements Role interface for Space Agency Representatives.
 *
 * @author Damien Muro
 * @author Ethan Patin
 * @author Christian Parra
 * @version 1.0
 */
public class SpaceAgencyRepresentativeRole implements Role{

    private final Scanner scanner = new Scanner(System.in);
    private final SpaceObjectsFileManager spaceObjectsFileManager = new SpaceObjectsFileManager();
    private final List<SpaceObject> debrisList = spaceObjectsFileManager.loadSpaceObjects("rso_metrics_columns_jumbled.csv");
    private final SpaceAgencyRepresentative spaceAgencyRepresentative = new SpaceAgencyRepresentative();


    private final String username; 
    private final String role;

    /**
     * Constructs a representative with credentials.
     *
     * @param username The representative's username.
     * @param role The representative's role.
     */
    public SpaceAgencyRepresentativeRole(String username, String role){
        this.username = username;
        this.role = role;
    }

    /**
     * Displays the Space Agency Representative-specific menu and allows the user
     * to select options for analyzing long-term impacts, generating density reports, or logging out.
     */
    public void showMenu(){
        String userLabel = username + " (" + role.toUpperCase() + ")";

        while (true) {
            System.out.println("\nCurrently Logged On As " + username + ":\n");
            System.out.println("====Space Agency Representative Menu====");
            System.out.println("1. Analyze Long Term Impact");
            System.out.println("2. Generate Density Report");
            System.out.println("3. LogOut\n");
            System.out.print("Select Option From The Given List: ");
            String option = scanner.nextLine(); 

            switch (option) {
                case "1":
                    longTermImpact();
                    break;
                case "2":
                    density_report();
                    break;
                case "3":
                    spaceObjectsFileManager.logSystemInteraction(userLabel, "Has Logged Out ");
                    System.out.println("Returning to the main menu. Logging out...");
                    return;

            }
        }
    }

    /**
     * Analyzes the long-term impact of space debris and displays a list of objects
     * with significant long-term impacts.
     */
    public void longTermImpact(){
        String userLabel = username + " (" + role.toUpperCase() + ")";
        spaceObjectsFileManager.logSystemInteraction(userLabel, "Analyzed Long Term Impact ");

        System.out.println("\n--- List Of Long Term Impact SpaceObjects ---\n");
        List<SpaceObject> longtermImpactObjects = spaceAgencyRepresentative.analyzeLongTermImpact(debrisList);
        
        if (longtermImpactObjects.isEmpty()) {
            System.out.println("No space objects found with significant long-term impact.");
            return;
        }
            for(SpaceObject currentObject : longtermImpactObjects){
                System.out.println(currentObject);
            
            }

        spaceObjectsFileManager.logSystemInteraction(userLabel, "Generated A List Of Objects With A Long Term Impact ");
    }

    /**
     * Prompts the user to enter a longitude range and generates a density report
     * for space objects within the specified range.
     */
    public void density_report() {
        String userLabel = username + " (" + role.toUpperCase() + ")";
        spaceObjectsFileManager.logSystemInteraction(userLabel, "Generated A Density Report ");
    
        double parsedMin = 0;
        double parsedMax = 0;

        String min_longitude;
        String max_longitude;
    
        while (true) {
            System.out.println("Enter The Minimum Longitude:");
            min_longitude = scanner.nextLine();
            System.out.println("Enter The Maximum Longitude:");
            max_longitude = scanner.nextLine();
    
            if (min_longitude.isEmpty() || max_longitude.isEmpty()) {
                System.out.println("Inputs cannot be empty. Please try again.\n");
                continue;
            }
    
            try {
                parsedMin = Double.parseDouble(min_longitude);
                parsedMax = Double.parseDouble(max_longitude);
    
                if (parsedMin > parsedMax) {
                    System.out.println("Minimum longitude cannot be greater than maximum longitude. Please try again.\n");
                    continue;
                }
    
                break;
            } catch (NumberFormatException e) {
                System.out.println("Invalid number format. Please enter numeric values.\n");
            }
        }
    
        List<SpaceObject> valid_SpaceObjects = spaceAgencyRepresentative.getObjectsInLongitudeRange(parsedMin, parsedMax, debrisList);
    
        for (SpaceObject currentSpaceObject : valid_SpaceObjects) {
            System.out.println(currentSpaceObject);
        }
    
        spaceAgencyRepresentative.generateDenistyReportCount(valid_SpaceObjects);

        spaceObjectsFileManager.logSystemInteraction(userLabel, "Gathered A Density Report For Objects In The A Given Range ");

    }
    

    
}
