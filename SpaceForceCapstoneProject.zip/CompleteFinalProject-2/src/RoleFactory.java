package src;

/**
 * Factory for creating role-specific menu implementations.
 *
 * @author Damien Muro
 * @author Ethan Patin
 * @author Christian Parra
 * @version 1.0
 */
public class RoleFactory {


    /**
     * Creates a Role implementation based on user's role.
     *
     * @param user The user needing a role.
     * @param userLogin The UserLogin instance.
     * @return Appropriate Role implementation.
     */
    public static Role getRole(User user, UserLogin userLogin){

        String roleName = user.getUserRole().toLowerCase();
        String username = user.getUserName();

        switch(roleName){
        case "scientist":
            return new ScientistRole(username, roleName);
        case "space agency representative":
            return new SpaceAgencyRepresentativeRole(username, roleName);
        case "policymaker": 
            //new PolicymakerRole();
        case "administrator":
            return new AdministratorRole(username, roleName, userLogin);
        default:
            return null; 
       }

    }


    /**
     * Validates if a role name is recognized by the system.
     *
     * @param roleName The role name to validate.
     * @return true if valid role, false otherwise.
     */
    public static boolean isValidRole(String roleName) {
        switch (roleName.toLowerCase()) {
            case "scientist":
            case "space agency representative":
            case "policymaker":
            case "administrator":
                return true;
            default:
                return false;
        }
    }
}
