package src;
/**
 * Represents a space object in the Space Debris Management System.
 * This abstract class provides the base properties and methods
 * for various types of space objects, such as satellites and debris.
 * 
 * @author Damien Muro
 * @author Ethan Patin
 * @author Christian Parra
 * @version Version 3.0
 */
public abstract class SpaceObject {
    private String record_id;
    private String norad_cat_id;
    private String satellite_name;
    private String country;
    private String approximate_orbit_type;
    private String object_type;
    private int launch_year;
    private String launch_site;
    private double longitude;
    private double avg_longitude;
    private String geohash;
    private String HRR_Category;
    private boolean is_nominated;
    private String nominated_at;
    private boolean has_dossier;
    private String last_updated_at;
    private String justification;
    private String[] focused_analysis;
    private int days_old;
    private long conjunction_count;
    private boolean is_unk_object;
    private String all_maneuvers;
    private int days_since_ob;
    private String recent_maneuvers;
    private double deltaV_90day;
    private boolean has_sister_debris;



    /**
     * Constructs a new SpaceObject with the specified parameters.
     *
     * @param record_id Unique identifier for the satellite record.
     * @param norad_cat_id NORAD catalog ID.
     * @param satellite_name Name of the satellite.
     * @param country Country of origin.
     * @param approximate_orbit_type Type of orbit (LEO, MEO, GEO, HEO).
     * @param object_type Type of space object.
     * @param launch_year Year of launch.
     * @param launch_site Launch site location.
     * @param longitude Current longitude.
     * @param avg_longitude Average longitude.
     * @param geohash Geohash location.
     * @param HRR_Category High Risk Resident category.
     * @param is_nominated Whether the object is nominated for tracking.
     * @param nominated_at Date when nominated.
     * @param has_dossier Whether a dossier exists.
     * @param last_updated_at Last update timestamp.
     * @param justification _
     * @param focused_analysis Array of focused analysis points.
     * @param days_old Age in days.
     * @param conjunction_count Number of conjunctions.
     * @param is_unk_object Whether object is unknown.
     * @param all_maneuvers All maneuver data.
     * @param days_since_ob Days since last observation.
     * @param recent_maneuvers Recent maneuver data.
     * @param deltaV_90day Delta V over 90 days.
     * @param has_sister_debris Whether sister debris exists.
     */
    public SpaceObject(String record_id, String norad_cat_id, String satellite_name, String country, String approximate_orbit_type,
                       String object_type, int launch_year, String launch_site, double longitude, double avg_longitude,
                       String geohash, String HRR_Category, boolean is_nominated, String nominated_at, boolean has_dossier,
                       String last_updated_at, String justification, String[] focused_analysis, int days_old, long conjunction_count,
                       boolean is_unk_object, String all_maneuvers, int days_since_ob, String recent_maneuvers, double deltaV_90day,
                       boolean has_sister_debris) {
        this.record_id = record_id;
        this.norad_cat_id = norad_cat_id;
        this.satellite_name = satellite_name;
        this.country = country;
        this.approximate_orbit_type = approximate_orbit_type;
        this.object_type = object_type;
        this.launch_year = launch_year;
        this.launch_site = launch_site;
        this.longitude = longitude;
        this.avg_longitude = avg_longitude;
        this.geohash = geohash;
        this.HRR_Category = HRR_Category;
        this.is_nominated = is_nominated;
        this.nominated_at = nominated_at;
        this.has_dossier = has_dossier;
        this.last_updated_at = last_updated_at;
        this.justification = justification;
        this.focused_analysis = focused_analysis;
        this.days_old = days_old;
        this.conjunction_count = conjunction_count;
        this.is_unk_object = is_unk_object;
        this.all_maneuvers = all_maneuvers;
        this.days_since_ob = days_since_ob;
        this.recent_maneuvers = recent_maneuvers;
        this.deltaV_90day = deltaV_90day;
        this.has_sister_debris = has_sister_debris;
    }

    /**
     * Gets the record ID of the space object.
     * @return The record ID
     */
    public String getRecord_id() {
        return record_id;
    }

    /**
     * Sets the record ID of the space object.
     * @param record_id The record ID to set
     */
    public void setRecord_id(String record_id) {
        this.record_id = record_id;
    }

    /**
     * Gets the NORAD catalog id of the space object.
     * @return NORAD catalog id
     */
    public String getNorad_cat_id() {
        return norad_cat_id;
    }

    /**
     * Sets the NORAD catalog id of the space object.
     * @param norad_cat_id The NORAD catalog id to set
     */
    public void setNorad_cat_id(String norad_cat_id) {
        this.norad_cat_id = norad_cat_id;
    }

    /**
     * Gets the name of the satellite.
     * @return The satellite name
     */
    public String getSatellite_name() {
        return satellite_name;
    }

     /**
     * Sets the name of the satellite.
     * @param satellite_name The name to set
     */
    public void setSatellite_name(String satellite_name) {
        this.satellite_name = satellite_name;
    }

    /**
     * Gets the country of origin for the space object.
     * @return The country of origin
     */
    public String getCountry() {
        return country;
    }

    /**
     * Sets the country of origin for the space object.
     * @param country The country to set
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * Gets the approximate orbit type of the space object.
     * @return The orbit type (LEO, MEO, HEO, GEO)
     */
    public String getApproximate_orbit_type() {
        return approximate_orbit_type;
    }

    /**
     * Sets the approximate orbit type of the space object.
     * @param approximate_orbit_type The orbit type to set
     */
    public void setApproximate_orbit_type(String approximate_orbit_type) {
        this.approximate_orbit_type = approximate_orbit_type;
    }

    /**
     * Gets the object type of the space object.
     * @return The object type (Debris, Payload, Rocket Body)
     */
    public String getObject_type() {
        return object_type;
    }

    /**
     * Sets the object type of the space object.
     * @param object_type The object type to set
     */
    public void setObject_type(String object_type) {
        this.object_type = object_type;
    }

    /**
     * Gets the launch year of the space object.
     * @return The launch year
     */
    public int getLaunch_year() {
        return launch_year;
    }


     /**
     * Sets the launch year of the space object.
     * @param launch_year The launch year to set
     */
    public void setLaunch_year(int launch_year) {
        this.launch_year = launch_year;
    }

    /**
     * Gets the launch site of the space object.
     * @return The launch site
     */
    public String getLaunch_site() {
        return launch_site;
    }


    /**
     * Sets the launch site of the space object.
     * @param launch_site The launch site to set
     */
    public void setLaunch_site(String launch_site) {
        this.launch_site = launch_site;
    }

    /**
     * Gets the current longitude of the space object.
     * @return The current longitude
     */
    public double getLongitude() {
        return longitude;
    }

    /**
     * Sets the current longitude of the space object.
     * @param longitude The longitude to set
     */
    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }


    /**
     * Gets the average longitude of the space object.
     * @return The average longitude
     */
    public double getAvg_longitude() {
        return avg_longitude;
    }

    /**
     * Sets the average longitude of the space object.
     * @param avg_longitude The average longitude to set
     */
    public void setAvg_longitude(double avg_longitude) {
        this.avg_longitude = avg_longitude;
    }

    /**
     * Gets the geohash of the space object.
     * @return The geohash location
     */
    public String getGeohash() {
        return geohash;
    }

    /**
     * Sets the geohash of the space object.
     * @param geohash The geohash to set
     */
    public void setGeohash(String geohash) {
        this.geohash = geohash;
    }

    /**
     * Gets the High Risk Resident category of the space object.
     * @return The geohash location
     */
    public String getHRR_Category() {
        return HRR_Category;
    }

    /**
     * Sets the High Risk Resident category of the space object.
     * @param HRR_Category The High Risk Resident category to set
     */
    public void setHRR_Category(String HRR_Category) {
        this.HRR_Category = HRR_Category;
    }

    /**
     * Checks if the space object is nominated for special tracking.
     * @return true if the object is nominated, false otherwise
     */
    public boolean isIs_nominated() {
        return is_nominated;
    }

     /**
     * Sets the nominated status of the space object.
     * @param is_nominated true to mark as nominated, false otherwise
     */
    public void setIs_nominated(boolean is_nominated) {
        this.is_nominated = is_nominated;
    }

    /**
     * Gets the timestamp when the object was nominated.
     * @return The nomination timestamp as a string, or null if not nominated
     */
    public String getNominated_at() {
        return nominated_at;
    }

    /**
     * Sets the timestamp when the object was nominated.
     * @param nominated_at The nomination timestamp string
     */
    public void setNominated_at(String nominated_at) {
        this.nominated_at = nominated_at;
    }

    /**
     * Checks if the space object has an associated dossier.
     * @return true if a dossier exists, false otherwise
     */
    public boolean isHas_dossier() {
        return has_dossier;
    }

    /**
     * Sets whether the space object has an associated dossier.
     * @param has_dossier true to indicate a dossier exists, false otherwise
     */
    public void setHas_dossier(boolean has_dossier) {
        this.has_dossier = has_dossier;
    }

    /**
     * Gets the timestamp of the last update for this object's record.
     * @return The last update timestamp as a string
     */
    public String getLast_updated_at() {
        return last_updated_at;
    }

    /**
     * Sets the timestamp of the last update for this object's record.
     * @param last_updated_at The update timestamp string
     */
    public void setLast_updated_at(String last_updated_at) {
        this.last_updated_at = last_updated_at;
    }

    /**
     * Gets the justification this space object.
     * @return The justification
     */
    public String getJustification() {
        return justification;
    }

    /**
     * Sets the justification this space object.
     * @param justification The justification
     */
    public void setJustification(String justification) {
        this.justification = justification;
    }

    /**
     * Gets the focused analysis points for this space object.
     * @return Array of analysis points
     */
    public String[] getFocused_analysis() {
        return focused_analysis;
    }

    /**
     * Sets the focused analysis points for this space object.
     * @param focused_analysis Array of analysis points
     */
    public void setFocused_analysis(String[] focused_analysis) {
        this.focused_analysis = focused_analysis;
    }

    /**
     * Gets the age in days of the space object.
     * @return The age in days
     */
    public int getDays_old() {
        return days_old;
    }

    /**
     * Sets the age in days of the space object.
     * @param days_old The age in days to set
     */
    public void setDays_old(int days_old) {
        this.days_old = days_old;
    }

    /**
     * Gets the total number of conjunction events for this space object.
     * @return The count of conjunction events
     */
    public long getConjunction_count() {
        return conjunction_count;
    }

    /**
     * Sets the total number of conjunction events for this space object.
     * @param conjunction_count The count of conjunction events
     */
    public void setConjunction_count(long conjunction_count) {
        this.conjunction_count = conjunction_count;
    }

    /**
     * Determines whether this object is classified as an unknown space object.
     * @return true if the object is unknown/unidentified, false otherwise
     */
    public boolean isIs_unk_object() {
        return is_unk_object;
    }

    /**
     * Sets the unknown object classification status.
     * @param is_unk_object true to mark as unknown, false for identified objects
     */
    public void setIs_unk_object(boolean is_unk_object) {
        this.is_unk_object = is_unk_object;
    }

    /**
     * Gets the complete maneuver history data for this space object.
     * @return String containing all recorded maneuvers
     */
    public String getAll_maneuvers() {
        return all_maneuvers;
    }

    /**
     * Sets the complete maneuver history data for this space object.
     * @param all_maneuvers String containing maneuver data in system format
     */
    public void setAll_maneuvers(String all_maneuvers) {
        this.all_maneuvers = all_maneuvers;
    }

    /**
     * Gets the number of days since the last observation of this object.
     * @return Days since last observation
     */
    public int getDays_since_ob() {
        return days_since_ob;
    }

    /**
     * Sets the number of days since the last observation.
     * @param days_since_ob Days since observation
     */
    public void setDays_since_ob(int days_since_ob) {
        this.days_since_ob = days_since_ob;
    }

    /**
     * Gets the recent maneuver data.
     * @return String containing recent maneuvers
     */
    public String getRecent_maneuvers() {
        return recent_maneuvers;
    }

    /**
     * Sets the recent maneuver data for this space object.
     * @param recent_maneuvers String containing recent maneuver data
     */
    public void setRecent_maneuvers(String recent_maneuvers) {
        this.recent_maneuvers = recent_maneuvers;
    }

     /**
     * Gets the total delta-V over the last 90 days.
     * @return Delta-V
     */
    public double getDeltaV_90day() {
        return deltaV_90day;
    }

    /**
     * Sets the 90-day delta-V measurement for this space object.
     * @param deltaV_90day Delta-V
     */
    public void setDeltaV_90day(double deltaV_90day) {
        this.deltaV_90day = deltaV_90day;
    }

    /**
     * Checks whether this object has associated sister debris.
     * @return true if sister debris exists, false otherwise
     */
    public boolean isHas_sister_debris() {
        return has_sister_debris;
    }

    /**
     * Sets whether this object has associated sister debris.
     * @param has_sister_debris true if sister debris exists, false otherwise
     */
    public void setHas_sister_debris(boolean has_sister_debris) {
        this.has_sister_debris = has_sister_debris;
    }

    /**
     * Determines the orbit status of the space object.
     * @return true if the object is in a stable orbit; otherwise, false.
     */
    public boolean orbitStatus() {
        return true;
    }

    /**
     * Sets the risk type for the space object.
     * @return A string representing the risk type.
     */
    public String setRiskType() {
        return "";
    }

}